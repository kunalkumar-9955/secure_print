@echo off
title Uninstall SecurePrint Connector
cls
echo ================================================================
echo        Uninstall SecurePrint Windows Connector
echo ================================================================
echo.

echo Removing Windows Auto-Start...
reg delete "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "SecurePrintAgent" /f >nul 2>&1

echo Stopping running agent instances...
taskkill /f /im SecurePrint.Agent.exe >nul 2>&1

echo.
echo Uninstallation completed. Auto-start removed.
echo.
pause
