@echo off
title SecurePrint Connector Setup
cls
echo ================================================================
echo        SecurePrint Windows Connector - 1-Click Setup
echo ================================================================
echo.
echo Installing SecurePrint Background Print Connector...
echo.

set "EXE_PATH=%~dp0SecurePrint.Agent.exe"

if not exist "%EXE_PATH%" (
    echo [ERROR] SecurePrint.Agent.exe not found in this folder!
    pause
    exit /b 1
)

echo [1/3] Registering Windows Auto-Start on Boot...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "SecurePrintAgent" /t REG_SZ /d "\"%EXE_PATH%\" --background" /f
if %errorlevel% equ 0 (
    echo       Auto-start registered successfully.
) else (
    echo       [WARNING] Could not write registry key.
)

echo.
echo [2/3] Checking Configuration...
set "CONFIG_DIR=%APPDATA%\SecurePrint"
if not exist "%CONFIG_DIR%" mkdir "%CONFIG_DIR%"

echo.
echo [3/3] Launching SecurePrint Connector...
start "" "%EXE_PATH%"

echo.
echo ================================================================
echo   INSTALLATION COMPLETE!
echo   The Connector will now start automatically whenever Windows starts.
echo   You only need to pair the computer ONCE.
echo ================================================================
echo.
timeout /t 5
