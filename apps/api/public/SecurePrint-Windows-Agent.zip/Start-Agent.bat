@echo off
title SecurePrint Desktop Print Agent
cls
echo ================================================================
echo   SecurePrint Windows Native Print Agent
echo   Automated Spooler Engine for HP, Epson, Thermal and Laser
echo ================================================================
echo.

set "CONFIG_DIR=%APPDATA%\SecurePrint"
set "CONFIG_FILE=%CONFIG_DIR%\agent-config.json"

if not exist "%CONFIG_DIR%" (
    echo [1/3] Initializing SecurePrint configuration directory...
    mkdir "%CONFIG_DIR%"
)

if not exist "%CONFIG_FILE%" (
    echo [2/3] Configuring default Cloud API Endpoint...
    (
        echo {
        echo   "ApiBaseUrl": "https://secure-print-api.onrender.com",
        echo   "MachineName": "%COMPUTERNAME%",
        echo   "AgentVersion": "1.0.0"
        echo }
    ) > "%CONFIG_FILE%"
    echo       Configured: https://secure-print-api.onrender.com
) else (
    echo [2/3] Existing SecurePrint pairing preserved. Keeping credentials.
)

echo [3/3] Ensuring Windows auto-start on computer boot...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" /v "SecurePrintAgent" /t REG_SZ /d "\"%~dp0SecurePrint.Agent.exe\" --background" /f >nul 2>&1

echo.
echo Starting SecurePrint Desktop Agent...
echo.
start "" "%~dp0SecurePrint.Agent.exe"
