================================================================
  SecurePrint Windows Native Print Connector (v1.1.0)
================================================================

FULLY AUTOMATED REAL PRINTING ENGINE FOR HP, EPSON, THERMAL & LASER

FIRST-TIME SETUP (ONLY ONCE):

1. Right-click "Install-Connector.bat" and run it (or run "Start-Agent.bat").
   This automatically registers the Connector to start with Windows.

2. In your SecurePrint Shop Web Console:
   - Go to Desktop Agents (https://secure-print-web.vercel.app/admin/agents)
   - Click "Connect Computer" to get your 6-digit code.

3. Enter the 6 digits in the Connector window and click "Connect to Shop".

4. Done! All physical Windows printers (e.g. HP LaserJet, Epson) are
   detected and synced automatically.

AFTER FIRST-TIME SETUP:

- Whenever Windows boots or restarts, the Connector starts automatically.
- No need to pair again.
- No need to enter printer IP or select printer for every job.
- Customer jobs print automatically to your default physical printer.
- Closing the window minimizes to background, continuing automatic printing.
================================================================
