================================================================
  SecurePrint Windows Native Print Agent (v1.0.0)
================================================================

HOW TO CONNECT YOUR COUNTER PRINTERS TO SECUREPRINT:

1. Double-click "Start-Agent.bat" (or "SecurePrint.Agent.exe").
2. The agent window will open and automatically detect all
   installed Windows printers (USB, Network, Thermal, Laser, Inkjet).
3. In your SecurePrint Shop Web Console:
   - Log into https://secure-print-web.vercel.app/login
   - Navigate to "Desktop Agents" (/admin/agents)
   - Click "Connect Computer" (or "Connect First Counter PC")
   - A 6-digit pairing code will be displayed on screen.
4. Enter the 6 digits into the Desktop Agent and click "Connect to Shop".
5. Status changes to "ONLINE" with green badge. All incoming customer
   print jobs will now automatically spool to your counter printer!

CLOUD SERVER ENDPOINT:
https://secure-print-api.onrender.com
================================================================
