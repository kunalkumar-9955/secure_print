@echo off
title SecurePrint Desktop Print Agent
cls
echo ================================================================
echo   SecurePrint Windows Native Print Agent
echo   Cloud Spooler Engine for Thermal, Laser and Inkjet Printers
echo ================================================================
echo.

set "CONFIG_DIR=%APPDATA%\SecurePrint"
set "CONFIG_FILE=%CONFIG_DIR%\agent-config.json"

if not exist "%CONFIG_DIR%" (
    echo [1/2] Initializing SecurePrint configuration directory...
    mkdir "%CONFIG_DIR%"
)

echo [1/2] Configuring Cloud API Endpoint (https://secure-print-api.onrender.com)...
(
    echo {
    echo   "ApiBaseUrl": "https://secure-print-api.onrender.com",
    echo   "MachineName": "%COMPUTERNAME%",
    echo   "AgentVersion": "1.0.0"
    echo }
) > "%CONFIG_FILE%"

echo       Configured: https://secure-print-api.onrender.com
echo.
echo [2/2] Starting SecurePrint Desktop Agent...
echo.
start "" "%~dp0SecurePrint.Agent.exe"
